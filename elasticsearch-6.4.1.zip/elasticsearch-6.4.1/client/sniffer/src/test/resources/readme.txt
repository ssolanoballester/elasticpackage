`*_node_http.json` contains files created by spinning up toy clusters with a
few nodes in different configurations locally at various versions. They are
for testing `ElasticsearchNodesSniffer` against different versions of
Elasticsearch.

See create_test_nodes_info.bash for how to create these.
